package AdjivaRegistrationPage;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.ie.InternetExplorerDriver;--> Uncomment this for IE Browser execution
//import org.openqa.selenium.firefox.FirefoxDriver;--> Uncomment this for Firefox Browser execution
import org.openqa.selenium.chrome.ChromeDriver; 
public class Base 
{
	static private WebDriver driver;
	WebDriver getDriver()
	{
		if(driver==null)
		{			
			//Uncomment below 2 lines for IE execution
			//System.setProperty("webdriver.ie.driver","D:/Ramana/Selenium/Selenium Artifects/Downloads/IEDriverIEDriverServer.exe");
			//driver=new InternetExplorerDriver();
			
			//Uncomment below 2 lines for Firefox execution
			//System.setProperty("webdriver.gecko.driver","D:/Ramana/Selenium/Selenium Artifects/Downloads/FirefoxDriver/geckodriver.exe");
			//driver=new FirefoxDriver();

			System.setProperty("webdriver.chrome.driver","D:/Ramana/Selenium/Selenium Artifects/Downloads/ChromeDriver/chromedriver.exe");			
			driver=new ChromeDriver();
			
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);			
		}
		return driver;
	}	
	//This method is to launch the respective URL
	public void goToUrl(String url)
	{
		driver.get(url);
	}
	
}
