package AdjivaRegistrationPage;

import org.junit.Test;
public class RegistrationTests {
	RegistrationPage registrationpage=new RegistrationPage();		
	@Test
	public void validRegistration()
	{
		// To launch the URL		<< http://adjiva.com/qa-test/ >>
		registrationpage.goToUrl("http://adjiva.com/qa-test/");
		
		//To set the value to the field << First Name >>
		registrationpage.setTxtFirstName("RAMANA MURTHY");
		//To set the value to the field << First Name >>
		registrationpage.setTxtLastName("BURE");
		//To click on the button << Submit >>
		registrationpage.clkBtnSubmit();		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
