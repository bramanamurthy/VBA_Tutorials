package AdjivaRegistrationPage;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrationPage extends Base
{
	//All object identification properties from Registration Page
	
	@FindBy(name="first_name")
	WebElement txtFirstName;
	
	@FindBy(name="last_name")
	WebElement txtLastName;
	
	@FindBy(name="department")
	WebElement txtDepartmentOffice;
	
	@FindBy(name="user_name")
	WebElement txtUserName;
	
	@FindBy(name="user_password")
	WebElement txtPassword;
	
	@FindBy(name="confirm_password")
	WebElement txtConfirmPasword;
	
	@FindBy(name="email")
	WebElement txtEmail;
	
	@FindBy(name="contact_no")
	WebElement txtContactNo;
	
	@FindBy(tagName="button")
	WebElement btnSubmit;
	
	//Invoking the elements from the current driver
	public RegistrationPage()	{
		PageFactory.initElements(getDriver(), this); 	}	
	
	public String getTxtFirstName()	{
		return  txtFirstName.getAttribute("value");	}	
	public void setTxtFirstName(String text)	{
		txtFirstName.sendKeys(text);	}	
	
	public String getTxtLastName()	{
		return  txtLastName.getAttribute("value");	}	
	public void setTxtLastName(String text)	{
		txtLastName.sendKeys(text);	}	
	
	public String getTxtDepartmentOffice()	{
		return  txtDepartmentOffice.getAttribute("value");	}	
	public void setTxtDepartmentOffice(String text)	{
		txtDepartmentOffice.sendKeys(text);	}	
	
	public String getTxtUserName()	{
		return  txtUserName.getAttribute("value");	}		
	public void setTxtUserName(String text)	{
		txtUserName.sendKeys(text);	}
	
	public String getTxtPassword()	{
		return  txtPassword.getAttribute("value");	}		
	public void setTxtPassword(String text)	{
		txtPassword.sendKeys(text);	}
	
	public String getConfirmPasword()	{
		return  txtConfirmPasword.getAttribute("value");	}		
	public void setConfirmPasword(String text)	{
		txtConfirmPasword.sendKeys(text);	}
	
	public String getTxtEmail()	{
		return  txtEmail.getAttribute("value");	}		
	public void setTxtEmail(String text)	{
		txtEmail.sendKeys(text);	}
	
	public String getContactNo()	{
		return  txtContactNo.getAttribute("value");	}		
	public void setContactNo(String text)	{
		txtContactNo.sendKeys(text);	}	
	
	//method to click on the Submit Button
	public void clkBtnSubmit()
	{
		btnSubmit.click();
	}
}
